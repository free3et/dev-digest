---
name: test-flakiness-checklist
description: Use when a diff adds or edits async, timer, network or randomness-dependent tests. Flag tests that can fail intermittently.
type: rubric
---

# Test flakiness checklist

For every test the diff adds or changes, look for a source of non-determinism that is not controlled:

1. **Time.** `Date.now()`, `new Date()`, `setTimeout`/`setInterval` or real sleeps without fake timers or an injected clock.
2. **Randomness.** `Math.random()`, `crypto.randomUUID()` used in an assertion, unseeded shuffles.
3. **Ordering.** Assertions that depend on object key order, `Promise.all` completion order, unordered DB rows without `ORDER BY`, or on another test having run first.
4. **Shared state.** Module-level mutable state, a shared database row, environment variables or globals that are not reset between tests.
5. **Async gaps.** A promise that is not awaited, `expect` inside a callback that may never run, polling with a fixed delay instead of waiting for a condition.
6. **External I/O.** Real network, real filesystem paths, ports that may be in use, Docker/testcontainers timing without a readiness wait.

Report **WARNING** with the exact source of non-determinism and the fix (fake timers, injected clock, seeded RNG, explicit `ORDER BY`, awaiting the condition). Report **CRITICAL** only when the flaky test guards a security or data-loss path and is the only test for it.
