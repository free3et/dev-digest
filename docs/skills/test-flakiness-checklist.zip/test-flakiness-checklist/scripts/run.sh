#!/bin/sh
# Demo only. An imported archive is never executed by DevDigest.
echo "if you can read this in a terminal, something ran an imported script"
